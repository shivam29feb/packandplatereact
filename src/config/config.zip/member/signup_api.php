<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// production connection string 
require_once __DIR__ . 'https://packandplate29febreact.rf.gd/config/connection.php';
// development connection string 
// require_once __DIR__ . '/../connection.php';

// Decode JSON input
$data = json_decode(file_get_contents("php://input"), true);

$username = $data['username'] ?? '';
$email = $data['email'] ?? '';
$password = $data['password'] ?? '';

echo "Username: $username, Email: $email, Password: $password";

$signup = new Signup();
$signup->signup($username, $email, $password);

// API logic for member signup
class Signup {
    public function signup($username, $email, $password) {
        global $pdo;

        try {
            $stmtGetUser = $pdo->prepare("SELECT user_username, user_email
                                          FROM users
                                          WHERE user_username = ? OR user_email = ?");
            $stmtGetUser->bindValue(1, $username);
            $stmtGetUser->bindValue(2, $email);
            $stmtGetUser->execute();
            $existingUser = $stmtGetUser->fetch(PDO::FETCH_ASSOC);

            if ($existingUser) {
                echo "User already exists";
                return;
            } else {
                $stmtInsertUser = $pdo->prepare("INSERT INTO users (user_username, user_email, user_password_hash, user_created_at)
                                                 VALUES (?, ?, ?, ?)");
                $stmtInsertUser->bindValue(1, $username);
                $stmtInsertUser->bindValue(2, $email);
                // PASSWORD_BCRYPT algorithm is used to encrypt the password
                $password = password_hash($password, PASSWORD_BCRYPT);
                $stmtInsertUser->bindValue(3, $password);
                $stmtInsertUser->bindValue(4, date('Y-m-d H:i:s'));

                $stmtInsertUser->execute();

                if ($stmtInsertUser->rowCount() > 0) {
                    echo "User inserted successfully";
                    $stmtGetUserId = $pdo->prepare("SELECT user_id
                                                    FROM users
                                                    WHERE user_username = ?");
                    $stmtGetUserId->bindValue(1, $username);
                    $stmtGetUserId->execute();
                    $userId = $stmtGetUserId->fetchColumn();
                    session_start();
                    $_SESSION['user_id'] = $userId;

                    
                } else {
                    echo "Failed to insert user";
                }
            }
        } catch (PDOException $e) {
            echo "Database error: " . $e->getMessage();
        }
    }
}

?>
